<?php

namespace App\Services\Api\V3;

use App\Models\User;
use App\Services\Api\V3\Contracts\KlinkaServiceInterface;
use App\Traits\Crud;
use Illuminate\Support\Facades\Hash;

class KlinkaService implements KlinkaServiceInterface
{
    public $modelClass = User::class;
    use Crud;
    public function filter()
    {
        return $this->modelClass::where('role', User::USER_ROLE_DIRECTOR)->get();
    }
    public function add($request)
    {
        $request = $request;
        if (isset($request->password)) {
            $request['password'] = Hash::make($request->password);
        }else{

            $request['password'] = Hash::make('1111');
        }
        $request['role'] =User::USER_ROLE_DIRECTOR;
        $result = $this->store($request);
        return $result;
    }
    public function edit($id, $request)
    {
        $request = $request;
        if (isset($request->password)) {
            $request['password'] = Hash::make($request->password);
        }
        $result = $this->update($id, $request);
        return $result;
    }
    // public function storeExcel($request)
    // {
    //     $dataExcel = json_decode($request?->dataExcel);
    //     if (count($dataExcel) > 0) {
    //         foreach ($dataExcel as $item) {
    //             Klinka::updateOrCreate(
    //                 [
    //                     'name' => $item?->name,
    //                 ], [
    //                     'name' => $item?->name,
    //                     'address' => $item?->name,
    //                     'photo' => $item?->photo,
    //                 ]);
    //         }
    //     }
    //     return $this->modelClass::all();
    // }

}
