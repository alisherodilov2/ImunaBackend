<?php

namespace App\Services\api;

use App\Models\History;
use App\Models\InAndOutPayment;
use App\Models\PayOffice;
use App\Models\User;
use App\Services\Api\Contracts\AuthServiceInterface;
use App\Traits\Crud;
use App\Traits\HistoryTraid;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;

class AuthService implements AuthServiceInterface
{
    public $modelClass = User::class;
    use Crud, HistoryTraid;
    public function register($request, $role)
    {
        $user = new User();
        $user->name = $request->input("name");
        $user->email = $request->input("email");
        $user->password = Hash::make($request->input("password"));
        $user->save();
        return response()->json([
            "status" => 200,
        ]);
    }
    public function login($request, $role = false)
    {
        $roles = [
            User::USER_ROLE_DIRECTOR,
        ];
        $where = [
            'role' => $request->role,
        ];
        if ($role) {
            $roles = [
                User::USER_ROLE_SUPPER_ADMIN,
            ];
            $where = [
                'login' => $request->login,
            ];
        }
        $user = User::Where($where)
            ->whereIn('role', $roles)
            ?->get();
        // $captcha = Captcha::Where("code", $request->input('captcha'))->first() ?? false;
        $captcha = true;
        if (count($user) == 0) {
            return ['xabar' => "role yoki parol noto'g'ri !"];
        } else {

            $passwords = passwordCheck($user, $request->password);
            // $passwords = Hash::check($request->password, $user->password) ?? false;
            // Log::info($user);
            if ($passwords) {
                if (!$captcha) {
                    return
                        ['xabar' => "Kaptcha noto'gri !"];
                } else {
                    // $captcha->delete();
                    $token = $passwords->createToken($request->password.$request->role.$request->login . '_Token')->plainTextToken;
                    // $token = $user->createToken($user->email . '_Token')->plainTextToken;
                    return [
                        'xabar' => 'ok',
                        'status' => 200,
                        'token' => $token,
                        "user" => ($passwords),
                    ];
                }
            } else {
                return  ['xabar' => "parol noto'g'ri kiritlgan!"];
            }
        }
    }
    public function logout($request)
    {
        $request->user()->currentAccessToken()->delete();
        return response()->json([
            'status' => 200,
            'massage' => 'Profilgan chiqildi',
        ]);
    }
    public function profile($request)
    {
        return Auth::user();
    }
    public function profileUpdate($request)
    {
        return $this->update(auth()->id(), $request);
    }
    public function passwordChange($request)
    {
        $user = $this->modelClass::find(auth()->id());
        $oldpas = $request->new_password === $request->con_new_password ? $request->old_password : '';
        $passwords = Hash::check($oldpas, $user->password) ?? false;
        if (!$passwords) {
            return [
                "status" => false,
                'message' => "Parol noto'g'ri kiritilgan ",
            ];
        } else {
            $user->password = Hash::make($request->input("new_password"));
            $user->save();
            return [
                "status" => 200,
                "message" => "parol o'zgartirldi",
            ];
        }
    }
}
