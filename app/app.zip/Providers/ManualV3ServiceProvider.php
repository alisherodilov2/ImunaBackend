<?php

namespace App\Providers;

use App\Services\Api\AuthService;
use App\Services\Api\Contracts\AuthServiceInterface;
use App\Services\Api\V3\Contracts\CustomerServiceInterface;
use App\Services\Api\V3\Contracts\KlinkaServiceInterface;
use App\Services\Api\V3\Contracts\MasterServiceInterface;
use App\Services\Api\V3\Contracts\OrderServiceInterface;
use App\Services\Api\V3\Contracts\PenaltyAmountServiceInterface;
use App\Services\Api\V3\Contracts\TgBotConnectServiceInterface;
use App\Services\Api\V3\Contracts\TgGroupServiceInterface;
use App\Services\Api\V3\CustomerService;
use App\Services\Api\V3\KlinkaService;
use App\Services\Api\V3\MasterService;
use App\Services\Api\V3\OrderService;
use App\Services\Api\V3\PenaltyAmountService;
use App\Services\Api\V3\TgBotConnectService;
use App\Services\Api\V3\TgGroupService;
use Carbon\Laravel\ServiceProvider;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\Schema;

class ManualV3ServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->singleton(AuthServiceInterface::class, AuthService::class);
        $this->app->singleton(TgGroupServiceInterface::class, TgGroupService::class);
        $this->app->singleton(KlinkaServiceInterface::class, KlinkaService::class);
        $this->app->singleton(MasterServiceInterface::class, MasterService::class);
        $this->app->singleton(OrderServiceInterface::class, OrderService::class);
        $this->app->singleton(TgBotConnectServiceInterface::class, TgBotConnectService::class);
        $this->app->singleton(CustomerServiceInterface::class, CustomerService::class);
        $this->app->singleton(PenaltyAmountServiceInterface::class, PenaltyAmountService::class);
      
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        Schema::defaultStringLength(191);
        Paginator::useBootstrap();
    }
}
