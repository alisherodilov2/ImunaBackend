<?php

namespace App\Models;

use App\Traits\Scopes;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, Scopes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    const USER_ROLE_SUPPER_ADMIN = 'super_admin';
    const USER_ROLE_DIRECTOR = 'director';

    protected $fillable = [
        'role',
        'password',
        'off_date',
        'telegram_id',
        'sms_api',
        'license',
        'site_url',
        'user_phone',
        'phone_1',
        'phone_2',
        'phone_3',
        'logo_photo',
        'user_photo',
        'blank_file',
        'address',
        'location',
        'name',
        'login',
        'password',
        'full_name',
    ];


    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];
    
    public $fileFields = [
        'logo_photo',
        'user_photo',
        'blank_file',
    ];
    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];
}
