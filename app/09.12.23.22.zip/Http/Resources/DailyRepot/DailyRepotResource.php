<?php

namespace App\Http\Resources\DailyRepot;

use Illuminate\Http\Resources\Json\JsonResource;

class DailyRepotResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return  [
            'id' => $this->id,
            'batch_number'=>$this->batch_number,
            'cash_price'=>$this->cash_price,
            'card_price'=>$this->card_price,
            'transfer_price'=>$this->transfer_price,
            'total_price'=>$this->total_price,
            'status'=>$this->status,
            'count'=>$this->dailyRepotClient->count(),
            'expence'=>$this->dailyRepotExpense?->sum(function($q){return $q->expense->price ?? 0;}) ?? 0,
            'current_date'=>$this->created_at->format('Y-m-d'),
        ];
    }
}
