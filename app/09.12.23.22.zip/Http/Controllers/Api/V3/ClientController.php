<?php

namespace App\Http\Controllers\Api\V3;

use App\Http\Controllers\Controller;
use App\Http\Resources\Client\ClientResource;
use App\Models\Client;
use App\Services\Api\V3\Contracts\ClientServiceInterface;
use App\Traits\ApiResponse;
use App\Traits\CommonApiControllerMethods;
use App\Traits\HistoryTraid;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class ClientController extends Controller
{

    public $modelClass = Client::class;

    use ApiResponse, CommonApiControllerMethods, HistoryTraid;

    public function index(Request $request, ClientServiceInterface $service)
    {
        if (isset($request->client_id)) {
            return $this->success($service->filter($request));
        }
        $res = ($service->filter($request));
        return $this->success($res);
    }
    public function counterpartyAllClient(Request $request, ClientServiceInterface $service)
    {
        $res = ($service->counterpartyAllClient($request));
        return $this->success($res);
    }
    public function register(Request $request, ClientServiceInterface $service)
    {
        // if ($request->status == 'payed' && $request->id > 0) {

        //     return $this->success(($service->register($request)));
        // }
        // return $this->success(new ClientResource($service->register($request)));
        return $this->success(($service->register($request)));
    }
    public function autocomplate(Request $request, ClientServiceInterface $service)
    {
        return $this->success(($service->autocomplate($request)));
    }
    public function doctorResult(Request $request, $id, ClientServiceInterface $service)
    {
        return $this->success(($service->doctorResult($id, $request)));
    }
    public function doctorRoom(Request $request, ClientServiceInterface $service)
    {
        return $this->success(($service->doctorRoom($request)));
    }
    public function update(Request $request, $id, ClientServiceInterface $service)
    {
        if (isset($request->password)) {
            $check = $this->modelClass::where(['role' => $request->role])
                ->where('id', '!=', $id)
                ->first();
            if ($check) {
                $passwords = Hash::check($request->password, $check->password) ?? false;
                if ($passwords) {
                    return $this->error([
                        'message' => 'Пользователь с таким именем уже существует',
                    ], 422);
                }
            }
        }
        return $this->success(new ClientResource($service->edit($id, $request)));
    }
    public function delete($id, ClientServiceInterface $service)
    {
        return $this->success([
            'data' =>  $service->delete($id),
        ]);
    }
    public function clientAllData(Request $request, ClientServiceInterface $service)
    {
        return $this->success(
            $service->clientAllData($request),
        );
    }
}
