<?php

namespace App\Services\Api\V3\Contracts;

interface ClientServiceInterface
{


    public function filter($request);
    // public function store($request);
    public function autocomplate($request);
    public function register($request);
    // public function add($request);
    public function update($id, $request);
    public function edit($id, $request);
    public function delete($id);
    public function doctorResult($id,$request);
    public function doctorRoom($request);
    public function clientAllData($request);

    public function counterpartyAllClient($request);
}
