<?php

namespace App\Services\Api\V3;

use App\Models\Client;
use App\Models\ClientValue;
use App\Models\CounterpartySetting;
use App\Models\GraphArchive;
use App\Models\ReferringDoctor;
use App\Models\Services;
use App\Models\User;
use App\Models\UserCounterpartyPlan;
use App\Services\Api\V3\Contracts\StatisticaServiceInterface;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class StatisticaService implements StatisticaServiceInterface
{
    function getMonthByIndex($index)
    {
        $oylar = [
            ["label" => "yanvar", "value" => 1],
            ["label" => "fevral", "value" => 2],
            ["label" => "mart", "value" => 3],
            ["label" => "aprel", "value" => 4],
            ["label" => "may", "value" => 5],
            ["label" => "iyun", "value" => 6],
            ["label" => "iyul", "value" => 7],
            ["label" => "avgust", "value" => 8],
            ["label" => "sentyabr", "value" => 9],
            ["label" => "oktyabr", "value" => 10],
            ["label" => "noyabr", "value" => 11],
            ["label" => "dekabr", "value" => 12],
        ];

        // Check if the index is valid
        foreach ($oylar as $month) {
            if ($month['value'] == $index) {
                return $month; // Return the month if found
            }
        }

        return null; // Return null if not found
    }
    public function statistica($request)
    {
        $currentMonthIndex = Carbon::now()->month;
        $is_all = false;
        if (isset($request->month) && $request->month > 0) {
            $currentMonthIndex = $request->month;
            $is_all = false;
        }
        if ((isset($request->is_all) && $request->is_all == 1)) {
            $is_all = true;
            $currentMonthIndex = Carbon::now()->month;
        }

        if ($request->is_today == 1) {
            $currentMonthIndex = Carbon::now()->month;
            $is_all = false;
        }


        $mulojagayozilgnlar = GraphArchive::
            // whereIn('user_id', User::where('owner_id', auth()->user()->id)->pluck('id'))
            // ->
            where(function ($q) {
                if (auth()->user()->role == User::USER_ROLE_DIRECTOR) {
                    $q->whereIn('user_id', User::where('owner_id', auth()->user()->id)->pluck('id'));
                } else {
                    $q->where('user_id', auth()->user()->id);
                }
            })
            ->whereHas('graphArchiveItem', function ($q) use ($request, $currentMonthIndex, $is_all) {
                if (isset($request->is_today) && $request->is_today == 1) {
                    $q->whereDate('agreement_date', now()->format('Y-m-d'));
                }
                if (!$is_all) {
                    $q->whereMonth('agreement_date', $currentMonthIndex);
                }
            })->with(['graphArchiveItem' => function ($q) use ($request) {
                $q->with(['client', 'graphItem.department']);
            }, 'person'])
            ->get();
        // optimallash kerak
        $bemorlar = Client::
            // whereIn('user_id', User::where('owner_id', auth()->user()->id)->pluck('id'))
            where(function ($q) {
                if (auth()->user()->role == User::USER_ROLE_DIRECTOR) {
                    $q->whereIn('user_id', User::where('owner_id', auth()->user()->id)->pluck('id'));
                } else {
                    $q->where('user_id', auth()->user()->id);
                }
            })
            ->where(function ($q) use ($request, $currentMonthIndex, $is_all) {
                if (isset($request->is_today) && $request->is_today == 1) {
                    $q->whereDate('created_at', now()->format('Y-m-d'));
                }
                if (!$is_all) {
                    $q->whereMonth('created_at', $currentMonthIndex);
                }
            });
        $ambulato = Client::whereNotIn('person_id', $mulojagayozilgnlar->pluck('person_id'))
            ->where(function ($q) {
                if (auth()->user()->role == User::USER_ROLE_DIRECTOR) {
                    $q->whereIn('user_id', User::where('owner_id', auth()->user()->id)->pluck('id'));
                } else {
                    $q->where('user_id', auth()->user()->id);
                }
            })
            // ->whereIn('user_id', User::where('owner_id', auth()->user()->id)->pluck('id'))
            ->where(function ($q) use ($request, $currentMonthIndex, $is_all) {
                if (isset($request->is_today) && $request->is_today == 1) {
                    $q->whereDate('created_at', now()->format('Y-m-d'));
                }
                if (!$is_all) {
                    $q->whereMonth('created_at', $currentMonthIndex);
                }
            })->get();

        $muolaja =  $mulojagayozilgnlar->where('status', GraphArchive::STATUS_LIVE); ///savol umumiymi yoki mulajasi tugamagnlarimi
        $yakunlangan =  GraphArchive::where('status', GraphArchive::STATUS_FINISH)
            ->where(function ($q) {
                if (auth()->user()->role == User::USER_ROLE_DIRECTOR) {
                    $q->whereIn('user_id', User::where('owner_id', auth()->user()->id)->pluck('id'));
                } else {
                    $q->where('user_id', auth()->user()->id);
                }
            })
            ->whereHas('graphArchiveItem', function ($q) use ($request, $currentMonthIndex, $is_all) {
                if (isset($request->is_today) && $request->is_today == 1) {
                    $q->whereDate('agreement_date', now()->format('Y-m-d'));
                }
                if (!$is_all) {
                    $q->whereMonth('agreement_date', $currentMonthIndex);
                }
            })->with(['graphArchiveItem' => function ($q) use ($request) {
                $q->with(['client', 'graphItem.department']);
            }, 'person']);



        $arxiv =  GraphArchive::where('status', GraphArchive::STATUS_ARCHIVE)
            ->where(function ($q) {
                if (auth()->user()->role == User::USER_ROLE_DIRECTOR) {
                    $q->whereIn('user_id', User::where('owner_id', auth()->user()->id)->pluck('id'));
                } else {
                    $q->where('user_id', auth()->user()->id);
                }
            })
            ->whereHas('graphArchiveItem', function ($q) use ($request, $currentMonthIndex, $is_all) {
                if (isset($request->is_today) && $request->is_today == 1) {
                    $q->whereDate('agreement_date', now()->format('Y-m-d'));
                }
                if (!$is_all) {

                    $q->whereMonth('agreement_date', $currentMonthIndex);
                }
            })
            ->with(['graphArchiveItem' => function ($q) use ($request) {
                $q->with(['client', 'graphItem.department']);
            }, 'person']);

        $kelmaganlar = GraphArchive::where(function ($q) {
            if (auth()->user()->role == User::USER_ROLE_DIRECTOR) {
                $q->whereIn('user_id', User::where('owner_id', auth()->user()->id)->pluck('id'));
            } else {
                $q->where('user_id', auth()->user()->id);
            }
        })->whereHas('graphArchiveItem', function ($q) use ($request, $currentMonthIndex, $is_all) {
            // $q->whereHas('graphItem', function ($q) use ($request, $currentMonthIndex, $is_all) {
            if (isset($request->is_today) && $request->is_today == '1') {
                $q->whereDate('agreement_date', now()->format('Y-m-d'));
            }
            if (!$is_all) {
                $q->whereMonth('agreement_date', $currentMonthIndex);
            }
            $q
                // $q
                ->whereNull('client_id')
                ->whereHas('department', function ($q) {
                    $time = Carbon::now()->format('H:i');
                    $date =  Carbon::now()->format('Y-m-d');
                    $q
                        ->whereRaw("graph_archive_items.agreement_date < '$date'")
                        ->orWhere(function ($q) use ($date, $time) {
                            $q->whereRaw("graph_archive_items.agreement_date = '$date'")
                                ->whereRaw("departments.work_end_time <= '$time'");
                        })
                    ;
                });
            // ->whereNull('client_id')
            // ->whereHas('department', function ($q) {
            //     // Using a join to reference columns directly
            //     $q
            //         // ->whereRow('CASE when  graph_archive_items.client_id IS NULL  1 else 0 end ')
            //         // ->whereRaw("CASE 
            //         // WHEN graph_archive_items.agreement_date = CURRENT_DATE  THEN (CASE WHEN  graph_archive_items.agreement_time IS NULL OR graph_archive_items.agreement_time = '-' THEN  (CASE WHEN departments.work_end_time = CURRENT_TIME then 1 else 0 end) else (departments.work_end_time > graph_archive_items.agreement_time)  end) ELSE (departments.work_end_time > graph_archive_items.agreement_time) END");
            //         ->whereRaw("
            //         CASE 
            //          WHEN graph_archive_items.agreement_date <= CURRENT_DATE
            //           THEN (CASE
            //              WHEN  graph_archive_items.agreement_time IS NULL OR graph_archive_items.agreement_time = '-'
            //                 THEN  (CASE
            //                  WHEN departments.work_end_time <= CURRENT_TIME  then 1 else 0 end)
            //                  else (departments.work_end_time >= graph_archive_items.agreement_time)  
            //             end) 
            //          END")
            //         // ->whereTime('departments.work_end_time','<=',now()->format('H:i'))
            //         ->whereNull('graph_archive_items.client_id')
            //     ;
            // });
            // });
        })
            ->with(['graphArchiveItem' => function ($q) use ($request) {
                $q

                    ->with(['client', 'graphItem.department']);
            }, 'person']);

        // bugungi sana borini olamiz
        $yangibemorlar = GraphArchive::where('status', GraphArchive::STATUS_LIVE)
            ->where(function ($q) {
                if (auth()->user()->role == User::USER_ROLE_DIRECTOR) {
                    $q->whereIn('user_id', User::where('owner_id', auth()->user()->id)->pluck('id'));
                } else {
                    $q->where('user_id', auth()->user()->id);
                }
            })
            ->whereHas('graphArchiveItem', function ($q) {
                // 1. Bugungi sanaga teng bo'lgan yozuvni olish
                $q->whereDate('agreement_date', now()->format('Y-m-d'));
            })
            ->with(['graphArchiveItem' => function ($q) use ($request) {
                $q->with(['client', 'graphItem.department']);
            }, 'person'])
            ->get() // Natijalarni olish
            ->filter(function ($item) {
                // 2. Har bir yozuvda graphArchiveItem bo'lsa va birinchi yozuvning sanasini tekshirish
                $first = $item->graphArchiveItem->first();
                return $first && $first->agreement_date == now()->format('Y-m-d'); // Agar birinchi yozuv bo'lsa va sanasi bugunga teng bo'lsa, qaytaring
            });
        $tugayotkanlar =  GraphArchive::where('status', GraphArchive::STATUS_LIVE)
            ->where(function ($q) {
                if (auth()->user()->role == User::USER_ROLE_DIRECTOR) {
                    $q->whereIn('user_id', User::where('owner_id', auth()->user()->id)->pluck('id'));
                } else {
                    $q->where('user_id', auth()->user()->id);
                }
            })
            ->whereHas('graphArchiveItem', function ($q) {
                // 1. Bugungi sanaga teng bo'lgan yozuvni olish
                $q->whereDate('agreement_date', now()->format('Y-m-d'))
                    ->orderBy('agreement_date', 'desc'); // Kamayish tartibida
                ;
            })
            ->with([
                'graphArchiveItem' => function ($q) {
                    // 1. Bugungi sanaga teng bo'lgan yozuvni olish
                    $q
                        ->with(['client', 'graphItem.department'])
                        ->orderBy('agreement_date', 'desc'); // Kamayish tartibida
                },
                'person'
            ])
            ->get() // Natijalarni olish
            ->filter(function ($item) {
                // 2. Har bir yozuvda graphArchiveItem bo'lsa va birinchi yozuvning sanasini tekshirish
                $first = $item->graphArchiveItem->first();
                return $first && $first->agreement_date == now()->format('Y-m-d'); // Agar birinchi yozuv bo'lsa va sanasi bugunga teng bo'lsa, qaytaring
            });

        if (isset($request->status)) {
            if ($request->status == 'ambulator') {
                return [
                    'data' => [...$ambulato->whereNull('parent_id')]
                ];
            }
            if ($request->status == 'live') {
                return [
                    'data' => [...$muolaja]
                ];
            }
            if ($request->status == 'archive') {
                return [
                    'data' => [...$arxiv->get()]
                ];
            }
            if ($request->status == 'kelmaganlar') {
                return [
                    'data' => [...$kelmaganlar->get()]
                ];
            }
            if ($request->status == 'finish') {
                return [
                    'data' => [...$yakunlangan->get()]
                ];
            }
            if ($request->status == 'bemorlar') {
                return [
                    'data' => Client::whereIn('person_id', $bemorlar->pluck('person_id')->unique())
                        ->whereNull('parent_id')
                        ->get()
                ];
            }
            if ($request->status == 'yangibemorlar') {
                return [
                    'data' =>  [...$yangibemorlar]

                ];
            }
            if ($request->status == 'tugayotkanlar') {
                return [
                    'data' =>  [...$tugayotkanlar]

                ];
            }
            if ($request->status == 'erkaklar') {
                return [
                    'data' =>
                    Client::whereIn('person_id', $bemorlar->pluck('person_id')->unique())
                        ->whereNull('parent_id')
                        ->where(function ($q) {
                            if (auth()->user()->role == User::USER_ROLE_DIRECTOR) {
                                $q->whereIn('user_id', User::where('owner_id', auth()->user()->id)->pluck('id'));
                            } else {
                                $q->where('user_id', auth()->user()->id);
                            }
                        })
                        ->where('sex', 'male')
                        ->get()
                    // $bemorlar
                    //     ->where('sex', 'male')
                    //     ->distinct('person_id') // Takrorlanmas qilish
                    //     ->get()

                ];
            }
            if ($request->status == 'muoljadagilar') {
                return [
                    'data' => [
                        ...$muolaja
                    ]
                ];
            }
            if ($request->status == 'ayollar') {
                return [
                    'data' =>
                    Client::whereIn('person_id', $bemorlar->pluck('person_id')->unique())
                        ->whereNull('parent_id')
                        ->where('sex', 'female')
                        ->where(function ($q) {
                            if (auth()->user()->role == User::USER_ROLE_DIRECTOR) {
                                $q->whereIn('user_id', User::where('owner_id', auth()->user()->id)->pluck('id'));
                            } else {
                                $q->where('user_id', auth()->user()->id);
                            }
                        })
                        ->get()
                    //     $bemorlar->where('sex', 'female')
                    //    ->distinct('person_id') // Takrorlanmas qilish
                    //         ->get()

                ];
            }
        }
        $bemorsoni =  $bemorlar->pluck('person_id')->unique()
            ->count();
        // Log::info('ayol', [$bemorlar->where('sex','!=' ,'male')->get()]);
        $erkaksoni = $bemorlar->where('sex', 'male')->pluck('person_id')->unique()->count();
        return [
            'ambulator' => $ambulato->pluck('person_id')->unique()
                ->count(),
            'mulojagayozilgnlar' => $bemorsoni > 0 ? ($mulojagayozilgnlar->pluck('person_id')->unique()->count() / $bemorsoni) * 100 : 0,
            'muoljadagilar' => $muolaja->count(),
            'bemorlar' => $bemorsoni,
            'kelmaganlar' => $kelmaganlar->count(),
            'yakunlanganlar' => $yakunlangan->count(),
            'arxivlanganlar' => $arxiv->count(),
            'yangibemorlar' => count($yangibemorlar),
            'erkaklar' => $erkaksoni,
            'ayollar' =>  $bemorsoni - $erkaksoni,
            'tugayotkanlar' => $tugayotkanlar->count(),
            'month' => $this->getMonthByIndex($currentMonthIndex),
        ];
        // $yakunlangan =  Client::where('is_check_doctor' ,Client::STATUS_FINISH)
        // ->count();
    }
    public function statisticaCounterparty($request)
    {
        $currentMonthIndex = Carbon::now()->month;
        $is_all = false;
        if (isset($request->month) && $request->month > 0) {
            $currentMonthIndex = $request->month;
            $is_all = false;
        }
        if ((isset($request->is_all) && $request->is_all == 1)) {
            $is_all = true;
            $currentMonthIndex = Carbon::now()->month;
        }

        if ($request->is_today == 1) {
            $currentMonthIndex = Carbon::now()->month;
            $is_all = false;
        }

        $referringDoctor = ReferringDoctor::where(function ($q) use ($currentMonthIndex, $request, $is_all) {
            $q->whereHas('referringDoctorBalance', function ($q) use ($currentMonthIndex, $request, $is_all) {
                if (isset($request->is_today) && $request->is_today == 1) {
                    $q->whereDate('date', now()->format('Y-m-d'));
                }
                if (!$is_all) {
                    $q->whereMonth('date', $currentMonthIndex);
                }
            });
        })
            ->with(['referringDoctorBalance' => function ($q) use ($currentMonthIndex) {
                $q
                    ->with('client')
                    ->whereMonth('date', $currentMonthIndex);
            }])
            ->where(function ($q) use ($request) {
                if (isset($request->show_id) && $request->show_id > 0) {
                    $q->whereIn('user_id', ReferringDoctor::where('user_id',  $request->show_id)->pluck('id'));
                } else {
                    $q->where('user_id', auth()->id());
                }
            });
        if (isset($request->show_id) && $request->show_id > 0) {
            $user =  User::find($request->show_id);
        } else {
            $user =  auth()->user();
        }

        $plan = CounterpartySetting::where(['ambulatory_service_id' => $user->ambulatory_service_id, 'treatment_service_id' => $user->treatment_service_id])
            // ->whereYear('created_at', date('Y'))
            ->where(function ($q) use ($request) {
                if (isset($request->show_id) && $request->show_id > 0) {
                    $q->where('user_id', $request->show_id);
                } else {
                    $q->where('user_id', auth()->id());
                }
            })
            ->where(function ($q) use ($currentMonthIndex) {
                $q->whereMonth('created_at',  $currentMonthIndex);
            })
            ->first();

        $ambulatory_service_id = $user->ambulatory_service_id;
        $treatment_service_id  = $user->treatment_service_id;
        if ($plan) {
            $ambulatory_service_id = $plan->ambulatory_service_id;
            $treatment_service_id = $plan->treatment_service_id;
            $treatment_id_data = json_decode($plan->treatment_id_data);
            $ambulatory_id_data = json_decode($plan->ambulatory_id_data);
        } else {
            $userCounterpartyPlan = UserCounterpartyPlan::where(function ($q) use ($request) {
                if (isset($request->show_id) && $request->show_id > 0) {
                    $q->where('user_id', $request->show_id);
                } else {
                    $q->where('user_id', auth()->id());
                }
            })->get();
            $treatment_id_data = $userCounterpartyPlan->where('status', 'treatment')->pluck('service_id');
            $ambulatory_id_data = $userCounterpartyPlan->where('status', 'ambulatory')->pluck('service_id');
        }



        $ambulatoryClietValue = ClientValue::where([
            // 'client_id' => auth()->id(),
            'is_active' => 1,
            // 'service_id' => $ambulatory_service_id,
        ])
            ->whereIn('service_id', $ambulatory_id_data)
            ->where('is_pay', 1)

            // ->where(DB::raw('total_price - (CASE WHEN discount <= 100 THEN (total_price * discount / 100) ELSE discount END)'), '=', DB::raw('pay_price'))

            ->whereHas('client', function ($q) use ($currentMonthIndex, $request, $is_all) {
                if (isset($request->show_id) && $request->show_id > 0) {
                    // $q
                    //     ->where('referring_doctor_id', $request->show_id);
                    $q->whereIn('referring_doctor_id', ReferringDoctor::where('user_id',  $request->show_id)->pluck('id'));
                } else {
                    $q->whereIn('referring_doctor_id', ReferringDoctor::where('user_id', auth()->id())->pluck('id'));
                }
                $q
                    ->whereMonth('created_at', $currentMonthIndex);
            });
        $ambulatoryClietValueQty = $ambulatoryClietValue->get()->sum('qty');
        $treatmentClietValue = ClientValue::where([
            // 'client_id' => auth()->id(),
            'is_active' => 1,
            // 'service_id' => $treatment_service_id,
        ])
            ->whereIn('service_id', $treatment_id_data)

            // ->where(DB::raw('total_price - (CASE WHEN discount <= 100 THEN (total_price * discount / 100) ELSE discount END)'), '=', DB::raw('pay_price'))
            ->where('is_pay', 1)
            ->whereHas('client', function ($q) use ($currentMonthIndex, $request) {
                if (isset($request->show_id) && $request->show_id > 0) {
                    // $q
                    //     ->where('referring_doctor_id', $request->show_id);
                    $q->whereIn('referring_doctor_id', ReferringDoctor::where('user_id',  $request->show_id)->pluck('id'));
                } else {
                    $q->whereIn('referring_doctor_id', ReferringDoctor::where('user_id', auth()->id())->pluck('id'));
                }
                $q
                    ->whereMonth('created_at', $currentMonthIndex);
            });
        $treatmentClietValueQty = $treatmentClietValue->get()->sum('qty');

        $ambulatory_service_kounteragent_price  = 0;
        $ambulatory_plan_qty = 0;
        $ambulatory_service_kounteragent_price = 0;

        $treatment_service_kounteragent_price  = 0;
        $treatment_plan_qty = 0;
        $treatment_service_kounteragent_price = 0;
        if ($plan) {
            $ambulatory_service_price = $plan->ambulatory_service_price;
            $ambulatory_plan_qty = $plan->ambulatory_plan_qty;
            $ambulatory_service_kounteragent_price = $plan->ambulatory_service_kounteragent_price;

            $treatment_service_price = $plan->treatment_service_price;
            $treatment_plan_qty = $plan->treatment_plan_qty;
            $treatment_service_kounteragent_price = $plan->treatment_service_kounteragent_price;
        } else {
            if (isset($request->show_id) && $request->show_id > 0) {
                $user =  User::find($request->show_id);
            }
            $ambulatory_service = Services::find($user->ambulatory_service_id);
            $ambulatory_service_price = $ambulatory_service->price ?? 0;
            $ambulatory_plan_qty = $user->ambulatory_plan_qty;
            $ambulatory_service_kounteragent_price = $ambulatory_service->kounteragent_contribution_price ?? 0;
            $treatment_service = Services::find($user->treatment_service_id);
            $treatment_service_price = $treatment_service->price ?? 0;
            $treatment_plan_qty = $user->treatment_plan_qty ?? 0;
            $treatment_service_kounteragent_price = $treatment_service->kounteragent_contribution_price ?? 0;
        }


        $clietValueTotal = ClientValue::where([
            // 'client_id' => auth()->id(),
            'is_active' => 1,
            // 'service_id' => $ambulatory_service_id,
        ])
            // ->whereIn('service_id', [...$treatment_id_data, ...$ambulatory_id_data])

            // ->where(DB::raw('total_price - (CASE WHEN discount <= 100 THEN (total_price * discount / 100) ELSE discount END)'), '=', DB::raw('pay_price'))
            ->where('is_pay', 1)
            ->whereHas('client', function ($q) use ($currentMonthIndex, $request, $is_all) {


                if (isset($request->is_today) && $request->is_today == 1) {
                    $q->whereDate('created_at', now()->format('Y-m-d'));
                }
                if (!$is_all) {
                    $q->whereMonth('created_at', $currentMonthIndex);
                }
                if (isset($request->show_id) && $request->show_id > 0) {
                    $q->whereIn('referring_doctor_id', ReferringDoctor::where('user_id',  $request->show_id)->pluck('id'));
                } else {
                    $q->whereIn('referring_doctor_id', ReferringDoctor::where('user_id', auth()->id())->pluck('id'));
                }
            })
            ->with('client');
        $clietValueTotal1 = ClientValue::where([
            // 'client_id' => auth()->id(),
            'is_active' => 1,
            // 'service_id' => $ambulatory_service_id,
        ])
            // ->whereIn('service_id', [...$treatment_id_data, ...$ambulatory_id_data])

            // ->where(DB::raw('total_price - (CASE WHEN discount <= 100 THEN (total_price * discount / 100) ELSE discount END)'), '=', DB::raw('pay_price'))
            ->where('is_pay', 1)
            ->whereHas('client', function ($q) use ($currentMonthIndex, $request, $is_all) {


                if (isset($request->is_today) && $request->is_today == 1) {
                    $q->whereDate('created_at', now()->format('Y-m-d'));
                }
                if (!$is_all) {
                    $q->whereMonth('created_at', $currentMonthIndex);
                }
                if (isset($request->show_id) && $request->show_id > 0) {
                    $q->whereIn('referring_doctor_id', ReferringDoctor::where('user_id',  $request->show_id)->pluck('id'));
                } else {
                    $q->whereIn('referring_doctor_id', ReferringDoctor::where('user_id', auth()->id())->pluck('id'));
                }
            })
            ->with('client');
        Log::info('treatment_id_data', [$treatment_id_data]);
        $service_count = $clietValueTotal->sum('qty');
        return [
            'balance' => $referringDoctor->get()->sum(function ($q) {
                return $q->referringDoctorBalance->sum('total_kounteragent_contribution_price');
            }),
            'clients' =>  $clietValueTotal->get()
                ->map(function ($doctor) {
                    return $doctor->client->person_id;
                })
                ->unique() // faqat noyob person_id larni olish
                ->count(),
            // 'clients' =>  $referringDoctor->get()
            // ->flatMap(function ($doctor) {
            //     return $doctor->referringDoctorBalance->map(function ($balance) {
            //         return $balance->client->person_id;
            //     });
            // })
            // ->unique() // faqat noyob person_id larni olish
            // ->count(),
            'service_count' => $service_count,
            // 'service_count' => $referringDoctor->get()->sum(function ($q) {
            //     return $q->referringDoctorBalance->sum('service_count');
            // }),
            'ambulatory_service' => [
                'ambulatory_plan_qty' => $ambulatory_plan_qty,
                'do' => $ambulatoryClietValueQty,
                'ambulatory_price' => $ambulatory_service_price *  $ambulatory_plan_qty,
                'do_ambulatory_price' => $ambulatory_service_price * $ambulatoryClietValueQty,
            ],
            'treatment_service' => [
                'treatment_plan_qty' => $treatment_plan_qty,
                'do' => $treatmentClietValueQty,

                'treatment_price' => $treatment_service_price *  $treatment_plan_qty,
                'do_treatment_price' => $treatment_service_price * $treatmentClietValueQty,
            ],
            'total_service' => [
                'ambulatory' => $clietValueTotal->whereIn('service_id', $ambulatory_id_data)->sum('qty'),
                'treatment' => $clietValueTotal1->whereIn('service_id', $treatment_id_data)->sum('qty'),
            ],
            'plan' => $plan
        ];
    }
}
