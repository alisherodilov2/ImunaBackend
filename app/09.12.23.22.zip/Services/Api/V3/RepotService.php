<?php

namespace App\Services\Api\V3;

use App\Http\Resources\DailyRepot\DailyRepotResource;
use App\Http\Resources\DoctorBalance\DoctorBalanceResource;
use App\Http\Resources\DoctorBalance\DoctorBalanceShowResource;
use App\Http\Resources\ReferringDoctor\ReferringDoctorResource;
use App\Http\Resources\Repot\RepotCcounterpartyResoruce;
use App\Models\Client;
use App\Models\ClientValue;
use App\Models\ClinetPaymet;
use App\Models\DailyRepot;
use App\Models\DoctorBalance;
use App\Models\Expense;
use App\Models\GraphArchive;
use App\Models\MaterialExpense;
use App\Models\ReferringDoctor;
use App\Models\Services;
use App\Models\User;
use App\Services\Api\V3\Contracts\RepotServiceInterface;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class RepotService implements RepotServiceInterface
{
    function getMonthByIndex($index)
    {
        $oylar = [
            ["label" => "yanvar", "value" => 1],
            ["label" => "fevral", "value" => 2],
            ["label" => "mart", "value" => 3],
            ["label" => "aprel", "value" => 4],
            ["label" => "may", "value" => 5],
            ["label" => "iyun", "value" => 6],
            ["label" => "iyul", "value" => 7],
            ["label" => "avgust", "value" => 8],
            ["label" => "sentyabr", "value" => 9],
            ["label" => "oktyabr", "value" => 10],
            ["label" => "noyabr", "value" => 11],
            ["label" => "dekabr", "value" => 12],
        ];

        // Check if the index is valid
        foreach ($oylar as $month) {
            if ($month['value'] == $index) {
                return $month; // Return the month if found
            }
        }

        return null; // Return null if not found
    }
    public function repot($request)
    {
        $currentMonthIndex = Carbon::now()->month;

        $is_all = false;
        $startDate = now();
        $endDate = now();
        $currentdate = now()->format('Y-m-d');
        if (isset($request->month) && $request->month > 0) {
            $currentMonthIndex = $request->month;
            $is_all = false;
        }
        if (isset($request->start_date)) {
            $parsedDate = Carbon::createFromFormat('Y-m-d', $request->start_date);
            if ($parsedDate->format('Y-m-d') ===  $request->start_date) {
                $startDate = $parsedDate;
            }
        }
        if (isset($request->end_date)) {
            $parsedDate = Carbon::createFromFormat('Y-m-d', $request->end_date);
            if ($parsedDate->format('Y-m-d') ===  $request->end_date) {
                $endDate = $parsedDate;
            }
        }
        $kontragent = User::where(['role' => User::USER_ROLE_COUNTERPARTY])
            ->where(function ($q) {
                if (auth()->user()->role == User::USER_ROLE_DIRECTOR) {
                    $q->where('owner_id', auth()->user()->id);
                } else {
                    $q->where('owner_id', auth()->user()->owner_id);
                }
            })
            ->whereHas('referringDoctor', function ($q) use ($currentMonthIndex, $currentdate) {
                $q->whereHas('referringDoctorBalance', function ($q) use ($currentMonthIndex, $currentdate) {
                    // $q->whereMonth('date', $currentMonthIndex);
                    $q->whereDate('date', $currentdate);
                });
            })->with(['referringDoctor' => function ($q) use ($currentMonthIndex, $currentdate) {
                $q->with(['referringDoctorBalance' => function ($q) use ($currentMonthIndex, $currentdate) {
                    $q->whereDate('date', $currentdate);
                }]);
            }])
            ->get();
        $docotr = User::where(['role' => User::USER_ROLE_DOCTOR])->where(function ($q) {
            if (auth()->user()->role == User::USER_ROLE_RECEPTION) {
                $q->where('owner_id', auth()->user()->owner_id);
            } else {
                $q->where('owner_id', auth()->user()->id);
            }
        })
            ->whereHas('doctorBalance', function ($q) use ($currentMonthIndex, $currentdate) {
                $q->whereDate('date', $currentdate);
            })->with(['doctorBalance' => function ($q) use ($currentMonthIndex, $currentdate) {
                $q->whereDate('date', $currentdate);
            }])
            ->get();
        $umumiy = Client::whereNotNull('parent_id')

            ->with(['clientPayment.user', 'clientValue.service.department'])
            ->where(function ($q) use ($startDate, $endDate) {
                if (auth()->user()->role == User::USER_ROLE_RECEPTION) {
                    $q->where('user_id', auth()->id());
                } else {
                    $q->whereIn('user_id', User::where('owner_id', auth()->id())->pluck('id'));
                }
                if ($startDate->format('Y-m-d') == $endDate->format('Y-m-d')) {
                    $q->whereDate('created_at', $startDate->format('Y-m-d'));
                } else {
                    $q->whereBetween('created_at', [$startDate, $endDate]);
                }
            })
            // ->where('is')
        ;
        if (isset($request->status) && $request->status == 'pay_all_client') {
            $expence =  Expense::where(function ($q) use ($startDate, $endDate) {

                if (auth()->user()->role == User::USER_ROLE_RECEPTION) {
                    $q->where('user_id', auth()->id());
                } else {
                    $q->whereIn('user_id', User::where('owner_id', auth()->id())->pluck('id'));
                }




                if ($startDate->format('Y-m-d') == $endDate->format('Y-m-d')) {
                    $q->whereDate('created_at', $startDate->format('Y-m-d'));
                } else {
                    $q->whereBetween('created_at', [$startDate, $endDate]);
                }
            })->get();



            return [
                'data' => $umumiy->get(),
                'start_date' => $startDate->format('Y-m-d'),
                'end_date' => $endDate->format('Y-m-d'),
                'expence' => [
                    'cash' => $expence
                        ->where('pay_type', 'cash')
                        ->sum('price'),
                    'card' => $expence
                        ->where('pay_type', 'card')
                        ->sum('price'),
                    'transfer' => $expence
                        ->where('pay_type', 'transfer')
                        ->sum('price'),
                    'total' => $expence->sum('price'),
                ],

            ];
        }
        $tolovlar = ClinetPaymet::where(function ($q) use ($startDate, $endDate) {
            if (auth()->user()->role == User::USER_ROLE_RECEPTION) {
                $q->whereIn('user_id', User::where('owner_id', auth()->user()->owner_id)->pluck('id'));
            } else {
                $q->whereIn('user_id', User::where('owner_id', auth()->id())->pluck('id'));
            }
        })
            ->whereHas('client', function ($q) use ($currentMonthIndex, $currentdate) {
                $q->whereDate('created_at', $currentdate);
            });
        $xizmatlar = ClientValue::where(function ($q) use ($startDate, $endDate) {
            if (auth()->user()->role == User::USER_ROLE_RECEPTION) {
                // $q->whereIn('user_id', User::where('owner_id', auth()->user()->owner_id)->pluck('id'));
            } else {
                $q->whereIn('user_id', User::where('owner_id', auth()->id())->pluck('id'));
            }
        })
          ->where('is_active',1)
            ->whereHas('client', function ($q) use ($currentMonthIndex, $currentdate) {
                $q->whereDate('created_at', $currentdate);
            });

        $expence =  Expense::where(function ($q) use ($startDate, $endDate) {
            if (auth()->user()->role == User::USER_ROLE_RECEPTION) {
                $q->where('user_id', auth()->id());
            } else {
                $q->whereIn('user_id', User::where('owner_id', auth()->id())->pluck('id'));
            }

            if ($startDate->format('Y-m-d') == $endDate->format('Y-m-d')) {
                $q->whereDate('created_at', $startDate->format('Y-m-d'));
            } else {
                $q->whereBetween('created_at', [$startDate, $endDate]);
            }
        })

            ->sum('price');
        $materialExpense =  MaterialExpense::where(function ($q) use ($startDate, $endDate) {
            if (auth()->user()->role == User::USER_ROLE_RECEPTION) {
                $q->where('user_id', auth()->id());
            } else {
                $q->whereIn('user_id', User::where('owner_id', auth()->id())->pluck('id'));
            }
            if ($startDate->format('Y-m-d') == $endDate->format('Y-m-d')) {
                $q->whereDate('created_at', $startDate->format('Y-m-d'));
            } else {
                $q->whereBetween('created_at', [$startDate, $endDate]);
            }
        })
            ->whereIn('user_id', User::where('owner_id', auth()->id())->pluck('id'))
            ->with(['materialExpenseItem.productReceptionItem'])->get()
            ->sum(function ($q) {
                return $q->materialExpenseItem->sum(function ($q2) {
                    return $q2->productReceptionItem->sum('price')  * $q2->qty;
                });
            });
        $dailyRepot = DailyRepot::where(function ($q) use ($startDate, $endDate) {
            if (auth()->user()->role == User::USER_ROLE_RECEPTION) {
                $q->where(['user_id' => auth()->id(), 'status' => 'start']);
            } else {
                $q->whereIn('user_id', User::where('owner_id', auth()->id())->pluck('id'));
            }
        })->whereDate('created_at', now()->format('Y-m-d'))->first();

        return [
            'kontragent' => $kontragent->sum(function ($clientValue) {
                return $clientValue->referringDoctor
                    ->sum(function ($q) {
                        return   $q->referringDoctorBalance->sum('total_kounteragent_contribution_price');
                    });
                // Agar qiymat mavjud bo'lmasa 0 qilamiz

            }),
            'doctor' => $docotr->sum(function ($clientValue) {
                return $clientValue->doctorBalance
                    ->sum(function ($q) {
                        return   $q->total_doctor_contribution_price;
                    });
                // Agar qiymat mavjud bo'lmasa 0 qilamiz

            }),
            'total_price' =>   $umumiy->sum('total_price'),
            'cash' =>   $tolovlar->sum('cash_price'),
            'card' =>   $tolovlar->sum('card_price'),
            'kassa' => $dailyRepot->total_price ?? 0,
            'transfer' =>   $tolovlar->sum('transfer_price'),
            'discount' =>   $xizmatlar->select(DB::raw("
            SUM(
                CASE 
                    WHEN discount <= 100 
                    THEN (total_price / 100) * discount
                    ELSE discount 
                END
            ) as total
        "))
                ->value('total') ?? 0,
            'debt' =>   $xizmatlar->select(DB::raw("
            SUM(
                CASE 
                    WHEN discount <= 100 
                    THEN (total_price - (total_price / 100 ) * discount) - pay_price
                    ELSE (total_price - discount) - pay_price
                END
            ) as total
        "))
                ->value('total') ?? 0,
            'expense' => $expence,
            'material_expense' => $materialExpense,
        ];
    }
    public function counterparty($request)
    {
        $currentMonthIndex = Carbon::now()->month;
        $is_all = false;
        if (isset($request->month) && $request->month > 0) {
            $currentMonthIndex = $request->month;
            $is_all = false;
        }
        $startDate = now();
        $endDate = now();
        if (isset($request->start_date)) {
            $parsedDate = Carbon::createFromFormat('Y-m-d', $request->start_date);
            if ($parsedDate->format('Y-m-d') ===  $request->start_date) {
                $startDate = $parsedDate;
            }
        }
        if (isset($request->end_date)) {
            $parsedDate = Carbon::createFromFormat('Y-m-d', $request->end_date);
            if ($parsedDate->format('Y-m-d') ===  $request->end_date) {
                $endDate = $parsedDate;
            }
        }

        // if ($id) {
        //     $find = User::where(['role' => User::USER_ROLE_COUNTERPARTY, 'owner_id' => auth()->id()])
        //         ->whereHas('referringDoctor', function ($q) use ($currentMonthIndex) {
        //             $q->whereHas('referringDoctorBalance', function ($q) use ($currentMonthIndex) {
        //                 $q->whereMonth('date', $currentMonthIndex);
        //             });
        //         })->with(['referringDoctor' => function ($q) use ($currentMonthIndex) {
        //             $q->with(['referringDoctorBalance' => function ($q) use ($currentMonthIndex) {
        //                 $q->whereMonth('date', $currentMonthIndex);
        //             }]);
        //         }])->find($id);
        //     return [
        //         'data' => $find->referringDoctor,
        //         'target' => $find
        //     ];
        // }
        $kontragent = User::where(['role' => User::USER_ROLE_COUNTERPARTY, 'owner_id' => auth()->id()])
            ->whereHas('referringDoctor', function ($q) use ($currentMonthIndex, $startDate, $endDate) {
                $q->whereHas('referringDoctorBalance', function ($q) use ($currentMonthIndex, $startDate, $endDate) {
                    // $q->whereMonth('date', $currentMonthIndex);
                    if ($startDate->format('Y-m-d') == $endDate->format('Y-m-d')) {
                        $q->whereDate('date', $endDate->format('Y-m-d'));
                    } else {
                        $q->whereBetween('date', [$startDate, $endDate]);
                    }
                });
            })->with(['referringDoctor' => function ($q) use ($currentMonthIndex, $startDate, $endDate) {
                $q->with(['referringDoctorBalance' => function ($q) use ($currentMonthIndex, $startDate, $endDate) {
                    // $q->whereMonth('date', $currentMonthIndex);
                    if ($startDate->format('Y-m-d') == $endDate->format('Y-m-d')) {
                        $q->whereDate('date', $endDate->format('Y-m-d'));
                    } else {
                        $q->whereBetween('date', [$startDate, $endDate]);
                    }
                }]);
            }])
            ->get();

        return  [
            'start_date' => $startDate->format('Y-m-d'),
            'end_date' => $endDate->format('Y-m-d'),

            'data' => RepotCcounterpartyResoruce::collection($kontragent)
        ];
    }

    public function doctor($request)
    {
        $currentMonthIndex = Carbon::now()->month;
        $is_all = false;
        if (isset($request->month) && $request->month > 0) {
            $currentMonthIndex = $request->month;
            $is_all = false;
        }
        $startDate = now();
        $endDate = now();
        if (isset($request->start_date)) {
            $parsedDate = Carbon::createFromFormat('Y-m-d', $request->start_date);
            if ($parsedDate->format('Y-m-d') ===  $request->start_date) {
                $startDate = $parsedDate;
            }
        }
        if (isset($request->end_date)) {
            $parsedDate = Carbon::createFromFormat('Y-m-d', $request->end_date);
            if ($parsedDate->format('Y-m-d') ===  $request->end_date) {
                $endDate = $parsedDate;
            }
        }
        $kontragent = User::where(['role' => User::USER_ROLE_DOCTOR])
            ->where(function ($q) {
                if (auth()->user()->role == User::USER_ROLE_RECEPTION) {
                    $q->where('owner_id', auth()->user()->owner_id);
                } else {
                    $q->where('owner_id', auth()->user()->id);
                }
            })
            ->whereHas('doctorBalance', function ($q) use ($currentMonthIndex, $startDate, $endDate) {
                if ($startDate->format('Y-m-d') == $endDate->format('Y-m-d')) {
                    $q->whereDate('date', $endDate->format('Y-m-d'));
                } else {
                    $q->whereBetween('date', [$startDate, $endDate]);
                }
            })
            ->with(['doctorBalance'=>function ($q) use ($currentMonthIndex, $startDate, $endDate) {
                if ($startDate->format('Y-m-d') == $endDate->format('Y-m-d')) {
                    $q->whereDate('date', $endDate->format('Y-m-d'));
                } else {
                    $q->whereBetween('date', [$startDate, $endDate]);
                }
            }, 'department'])
            ->get();
        return  [
            'start_date' => $startDate->format('Y-m-d'),
            'end_date' => $endDate->format('Y-m-d'),

            'data' => DoctorBalanceResource::collection($kontragent)
        ];
    }
    public function doctorShow($id, $request)
    {
        $per_page = $request->per_page ?? 50;
        $currentMonthIndex = Carbon::now()->month;
        $is_all = false;
        if (isset($request->month) && $request->month > 0) {
            $currentMonthIndex = $request->month;
            $is_all = false;
        }

        $startDate = now();
        $endDate = now();
        if (isset($request->start_date)) {
            $parsedDate = Carbon::createFromFormat('Y-m-d', $request->start_date);
            if ($parsedDate->format('Y-m-d') ===  $request->start_date) {
                $startDate = $parsedDate;
            }
        }
        if (isset($request->end_date)) {
            $parsedDate = Carbon::createFromFormat('Y-m-d', $request->end_date);
            if ($parsedDate->format('Y-m-d') ===  $request->end_date) {
                $endDate = $parsedDate;
            }
        }
        $calc =  DoctorBalance::where('doctor_id', $id);
        $total_price = $calc->sum('total_price');
        $service_count = $calc->sum('service_count');
        $total_doctor_contribution_price = $calc->sum('total_doctor_contribution_price');
        $data = $calc
            ->where(function ($q) use ($currentMonthIndex, $startDate, $endDate) {
                if ($startDate->format('Y-m-d') == $endDate->format('Y-m-d')) {
                    $q->whereDate('date', $endDate->format('Y-m-d'));
                } else {
                    $q->whereBetween('date', [$startDate, $endDate]);
                }
            })
            ->where(function ($q) use ($request) {
                if (isset($request->full_name)) {
                    $q->whereHas('client', function ($q) use ($request) {
                        $q->where(DB::raw("CONCAT(first_name, ' ', last_name)"), 'LIKE', "%{$request->full_name}%");
                    });
                }
            })
            ->with('client:id,first_name,last_name,person_id')
            ->paginate($per_page);
        return  [
            'start_date' => $startDate->format('Y-m-d'),
            'end_date' => $endDate->format('Y-m-d'),
            'data' => DoctorBalanceShowResource::collection($data->items()),
            'total' => $data->total(),
            'last_page' => $data->lastPage(),
            'current_page' => $data->currentPage(),
            'per_page' => $data->perPage(),
            'total_price' => $total_price,
            'service_count' => $service_count,
            'total_doctor_contribution_price' => $total_doctor_contribution_price
        ];
    }
    public function doctorShowService($id)
    {

        $data = DoctorBalance::find($id);
        $contribution_data = collect(json_decode($data->contribution_data)); // Decode JSON and wrap it in a collection

        // Get service names for each service_id
        $enriched_data = $contribution_data->map(function ($item) {
            $service = Services::find($item->service_id); // Fetch service by ID
            $item->id = 0; // Add service name
            $item->service_name = $service ? $service->name : null; // Add service name
            return $item; // Return modified item
        });

        return  $enriched_data;
    }
    public function dailyRepot($request)
    {
        $currentMonthIndex = Carbon::now()->month;
        $is_all = false;
        if (isset($request->month) && $request->month > 0) {
            $currentMonthIndex = $request->month;
            $is_all = false;
        }
        $startDate = now();
        $endDate = now();
        if (isset($request->start_date)) {
            $parsedDate = Carbon::createFromFormat('Y-m-d', $request->start_date);
            if ($parsedDate->format('Y-m-d') ===  $request->start_date) {
                $startDate = $parsedDate;
            }
        }
        if (isset($request->end_date)) {
            $parsedDate = Carbon::createFromFormat('Y-m-d', $request->end_date);
            if ($parsedDate->format('Y-m-d') ===  $request->end_date) {
                $endDate = $parsedDate;
            }
        }
        $status = 'start';
        if (isset($request->status)) {
            $status = $request->status;
        }
        $kontragent = DailyRepot::where(function ($q) use ($status, $startDate, $endDate) {
            if (auth()->user()->role == User::USER_ROLE_RECEPTION) {
                $q->where(['user_id' => auth()->id(), 'status' => $status]);
            } else {
                $q->whereIn('user_id', User::where('owner_id', auth()->user()->owner_id)->pluck('id'));
            }
            // if ($startDate->format('Y-m-d') == $endDate->format('Y-m-d')) {
            //     $q->whereDate('created_at', $endDate->format('Y-m-d'));
            // } else {
            //     $q->whereBetween('created_at', [$startDate, $endDate]);
            // }
        })
            ->with(['dailyRepotExpense.expense', 'dailyRepotClient'])
            ->orderBy('created_at', 'desc')
            ->get();

        return  [
            'start_date' => $startDate->format('Y-m-d'),
            'end_date' => $endDate->format('Y-m-d'),
            'status' => $status,
            'data' => DailyRepotResource::collection($kontragent)
        ];
    }
    public function dailyRepotShow($id)
    {

        $find = DailyRepot::with(['dailyRepotExpense.expense.expenseType', 'dailyRepotClient', 'user.owner'])->where('user_id', auth()->id())
            ->find($id);
        $count = DailyRepot::whereDate('created_at', $find->created_at)
            ->where('user_id', auth()->id())
            ->where('status', 'finish')
            ->count();
        return  [
            'data' => [...$find->toArray(), 'partiya' => $count]
        ];
    }
    public function counterpartyShow($id, $request)
    {
        $currentMonthIndex = Carbon::now()->month;
        $is_all = false;
        if (isset($request->month) && $request->month > 0) {
            $currentMonthIndex = $request->month;
            $is_all = false;
        }
        $startDate = now();
        $endDate = now();
        if (isset($request->start_date)) {
            $parsedDate = Carbon::createFromFormat('Y-m-d', $request->start_date);
            if ($parsedDate->format('Y-m-d') ===  $request->start_date) {
                $startDate = $parsedDate;
            }
        }
        if (isset($request->end_date)) {
            $parsedDate = Carbon::createFromFormat('Y-m-d', $request->end_date);
            if ($parsedDate->format('Y-m-d') ===  $request->end_date) {
                $endDate = $parsedDate;
            }
        }
        // if ($id) {
        //     $find = User::where(['role' => User::USER_ROLE_COUNTERPARTY, 'owner_id' => auth()->id()])
        //         ->whereHas('referringDoctor', function ($q) use ($currentMonthIndex) {
        //             $q->whereHas('referringDoctorBalance', function ($q) use ($currentMonthIndex) {
        //                 $q->whereMonth('date', $currentMonthIndex);
        //             });
        //         })->with(['referringDoctor' => function ($q) use ($currentMonthIndex) {
        //             $q->with(['referringDoctorBalance' => function ($q) use ($currentMonthIndex) {
        //                 $q->whereMonth('date', $currentMonthIndex);
        //             }]);
        //         }])->find($id);
        //     return [
        //         'data' => $find->referringDoctor,
        //         'target' => $find
        //     ];
        // }
        return [
            'start_date' => $startDate->format('Y-m-d'),
            'end_date' => $endDate->format('Y-m-d'),
            'data' => ReferringDoctorResource::collection(User::where(['role' => User::USER_ROLE_COUNTERPARTY, 'owner_id' => auth()->id()])
                ->whereHas('referringDoctor', function ($q) use ($currentMonthIndex, $startDate, $endDate) {
                    $q->whereHas('referringDoctorBalance', function ($q) use ($currentMonthIndex, $startDate, $endDate) {
                        // $q->whereMonth('date', $currentMonthIndex);
                        if ($startDate->format('Y-m-d') == $endDate->format('Y-m-d')) {
                            $q->whereDate('date', $endDate->format('Y-m-d'));
                        } else {
                            $q->whereBetween('date', [$startDate, $endDate]);
                        }
                    });
                })->with(['referringDoctor' => function ($q) use ($currentMonthIndex, $startDate, $endDate) {
                    $q->with(['referringDoctorBalance' => function ($q) use ($currentMonthIndex, $startDate, $endDate) {
                        // $q->whereMonth('date', $currentMonthIndex);
                        if ($startDate->format('Y-m-d') == $endDate->format('Y-m-d')) {
                            $q->whereDate('date', $endDate->format('Y-m-d'));
                        } else {
                            $q->whereBetween('date', [$startDate, $endDate]);
                        }
                    }]);
                }])
                ->find($id)?->referringDoctor ?? [])
        ];
    }
    public function counterpartyClientShow($id, $request)
    {
        $currentMonthIndex = Carbon::now()->month;
        $is_all = false;
        if (isset($request->month) && $request->month > 0) {
            $currentMonthIndex = $request->month;
            $is_all = false;
        }
        $startDate = now();
        $endDate = now();
        if (isset($request->start_date)) {
            $parsedDate = Carbon::createFromFormat('Y-m-d', $request->start_date);
            if ($parsedDate->format('Y-m-d') ===  $request->start_date) {
                $startDate = $parsedDate;
            }
        }
        if (isset($request->end_date)) {
            $parsedDate = Carbon::createFromFormat('Y-m-d', $request->end_date);
            if ($parsedDate->format('Y-m-d') ===  $request->end_date) {
                $endDate = $parsedDate;
            }
        }
        // if ($id) {
        //     $find = User::where(['role' => User::USER_ROLE_COUNTERPARTY, 'owner_id' => auth()->id()])
        //         ->whereHas('referringDoctor', function ($q) use ($currentMonthIndex) {
        //             $q->whereHas('referringDoctorBalance', function ($q) use ($currentMonthIndex) {
        //                 $q->whereMonth('date', $currentMonthIndex);
        //             });
        //         })->with(['referringDoctor' => function ($q) use ($currentMonthIndex) {
        //             $q->with(['referringDoctorBalance' => function ($q) use ($currentMonthIndex) {
        //                 $q->whereMonth('date', $currentMonthIndex);
        //             }]);
        //         }])->find($id);
        //     return [
        //         'data' => $find->referringDoctor,
        //         'target' => $find
        //     ];
        // }
        return (ReferringDoctor::where(function ($q) use ($startDate, $endDate) {
            // if (isset($request->is_repot)) {
            $q->whereHas('referringDoctorBalance', function ($q) use ($startDate, $endDate) {
                if ($startDate->format('Y-m-d') == $endDate->format('Y-m-d')) {
                    $q->whereDate('date', $startDate->format('Y-m-d'));
                } else {
                    $q->whereBetween('date', [$startDate, $endDate]);
                }
            });
            // }
        })
            ->with(['referringDoctorBalance' => function ($q) use ($request, $startDate, $endDate) {
                // $q->whereHas('referringDoctorBalance', function ($q) use ($startDate, $endDate) {
                if ($startDate->format('Y-m-d') == $endDate->format('Y-m-d')) {
                    $q->whereDate('date', $endDate->format('Y-m-d'))
                        ->with('client')
                    ;
                } else {
                    $q->whereBetween('date', [$startDate, $endDate])
                        ->with('client')
                    ;
                    // $q->with('client');
                    // });
                }
            }])
            // ->where('user_id', auth()->id())
            ->find($id));
    }


    // DailyRepot
    function dailyRepotUpdate($request)
    {
        // $client = ClinetPaymet::whereDate('created_at', now()->format('Y-m-d'))
        //     ->where('user_id', auth()->id())
        //     // ->whereIn('user_id',User::where('owner_id',auth()->user()->owner_id)->pluck('id'))
        //     ->get();
        // $expnece = Expense::whereDate('created_at', now()->format('Y-m-d'))
        //     ->where('user_id', auth()->id())
        //     ->get();
        // $dailyRepot = DailyRepot::whereDate('created_at', now()->format('Y-m-d'))
        //     ->where('user_id', auth()->id())
        //     ->first();
        // if (!$dailyRepot) {
        //     // $dailyRepot = DailyRepot::create([
        // }

        $dailyRepot = DailyRepot::find($request->id);
        $dailyRepot->update($request->all());
        return (DailyRepot::with(['dailyRepotExpense.expense.expenseType', 'dailyRepotClient'])->find($dailyRepot->id));
    }
}
