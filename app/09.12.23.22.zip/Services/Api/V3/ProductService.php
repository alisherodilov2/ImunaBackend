<?php

namespace App\Services\Api\V3;

use App\Http\Resources\Product\ProductRepotResource;
use App\Http\Resources\Product\ProductRepotShowResource;
use App\Models\Client;
use App\Models\ClientUseProduct;
use App\Models\Product;
use App\Models\ProductReceptionItem;
use App\Models\User;
use App\Services\Api\V3\Contracts\ProductServiceInterface;
use App\Traits\Crud;
use Carbon\Carbon;
use Illuminate\Support\Facades\Hash;

class ProductService implements ProductServiceInterface
{
    public $modelClass = Product::class;
    use Crud;
    public function filter($request)
    {
        return $this->modelClass::
        // where('user_id', auth()->user()->owner_id)
        //     ->
            where(function ($q) use ($request) {
                if (isset($request->is_material)) {
                    $q->whereHas('prodcutCategory', function ($q) {
                        $q->where('is_material', 1);
                    });
                }
                if (auth()->user()->role === User::USER_ROLE_RECEPTION) {
                    $q->where('user_id', auth()->user()->owner_id)
                        ->orWhere('user_id', auth()->user()->id)
                    ;
                } else {
                    $q->where('user_id', auth()->user()->id)
                    ->orWhereIn('user_id', User::where('owner_id', auth()->user()->id)->pluck('id'))
                    ;
                }
            })
            ->with(['prodcutCategory', 'productReceptionItem'])
            ->get();
    }
    public function add($request)
    {
        $request = $request;
        $id = auth()->id();
        $request['user_id'] = $id;

        $result = $this->store($request);
        return $this->modelClass::where('id', $result->id)->with(['prodcutCategory', 'productReceptionItem'])->first();
    }
    public function edit($id, $request)
    {
        $request = $request;
        $result = $this->update($id, $request);
        return $this->modelClass::where('id', $result->id)->with(['prodcutCategory', 'productReceptionItem'])->first();
    }

    public function show($id, $request)
    {
        $today = Carbon::today();
        // $alert_dedline_day = $this->alert_dedline_day;

        // // $fiveDaysLater = $today->copy()->addDays($this->expiration_day);
        // $danger_qty =  $productReceptionItem->filter(function ($item) use ($today,$alert_dedline_day ) {
        //     $daysRemaining = $today->diffInDays(Carbon::parse($item->expiration_date), false);

        //     // Faqat 5 kundan kichik yoki teng bo'lganlarini qaytaramiz
        //     return $daysRemaining >= 0 && $daysRemaining <= $alert_dedline_day;
        // })->sum('qty');
        $product = $this->modelClass::find($id);
        // return $this->modelClass::with(['productReceptionItem' => function ($q) use ($id,$today) {
        //     $q->where(function ($q) use ($id,$today) {
        //         $fiveDaysLater = $today->copy()->subDays($this->alert_dedline_day);
        //     });
        //     $q->with(['prodcut', 'prodcutCategory']);
        // }])->find($id);
        return ProductReceptionItem::where('product_id', $id)
            ->where(function ($q) use ($id, $today, $product, $request) {
                if (isset($request->status) && $request->status == 'danger') {
                    // $fiveDaysLater = $today->copy()->subDays($product->alert_dedline_day);
                    // $q->where('expiration_date', '<=', $fiveDaysLater);
                    $q->whereRaw('DATEDIFF(expiration_date, ?) <= ?', [$today, $product->alert_dedline_day]);
                }
            })
            ->with(['prodcut', 'prodcutCategory'])->get();
    }

    public function repot($request)
    {
        $startDate = now();
        $endDate = now();
        if (isset($request->start_date)) {
            $parsedDate = Carbon::createFromFormat('Y-m-d', $request->start_date);
            if ($parsedDate->format('Y-m-d') ===  $request->start_date) {
                $startDate = $parsedDate;
            }
        }
        if (isset($request->end_date)) {
            $parsedDate = Carbon::createFromFormat('Y-m-d', $request->end_date);
            if ($parsedDate->format('Y-m-d') ===  $request->end_date) {
                $endDate = $parsedDate;
            }
        }
        $clientUseProducts = ClientUseProduct::where(function ($q) use ($startDate, $endDate) {
      
                if (auth()->user()->role === User::USER_ROLE_RECEPTION) {
                    $q->where('user_id', auth()->user()->owner_id)
                        ->orWhere('user_id', auth()->user()->id)
                    ;
                } else {
                    $q->where('user_id', auth()->user()->id)
                        ->orWhereIn('user_id', User::where('owner_id', auth()->user()->id)->pluck('id'))
                    ;
                }
         
            if ($startDate->format('Y-m-d') == $endDate->format('Y-m-d')) {
                $q
                    ->whereDate('created_at', $endDate->format('Y-m-d'));
            } else {
                $q
                    ->whereBetween('created_at', [$startDate, $endDate]);
            }
        })
            ->selectRaw('
        DATE(created_at) as date,
         GROUP_CONCAT(DISTINCT CONCAT("[", product_reception_item_id, ",", qty, ",", client_id, "]")) AS product_reception_item_ids,
        GROUP_CONCAT(DISTINCT product_id) as product_ids,
        COUNT(*) as count
    ')
            ->groupBy('date')
            ->get();
        return [
            'data' => ProductRepotResource::collection($clientUseProducts),
            'start_date' => $startDate->format('Y-m-d'),
            'end_date' => $endDate->format('Y-m-d'),
        ];
    }

    public function repotShow($request)
    {

        $clientUseProducts = ClientUseProduct::where(function ($q) use ($request) {
            $q->whereDate('created_at', $request->date);
        })
            ->selectRaw('
                client_id, 
                product_id, 
                GROUP_CONCAT(DISTINCT CONCAT("[", product_reception_item_id, ",", qty, "]")) AS product_reception_item_ids
            ')
            ->groupBy('client_id', 'product_id')
            ->with(['client:id,first_name,last_name,phone', 'product.prodcutCategory'])  // Agar siz client relatsiyasini olishni istasangiz
            ->get();
        return ProductRepotShowResource::collection($clientUseProducts);
    }
}
