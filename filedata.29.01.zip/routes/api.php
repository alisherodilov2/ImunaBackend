<?php

use App\Http\Controllers\Api\TelegramController;
use App\Http\Controllers\Api\V3\TelegramBotController;
use App\Models\Client;
use App\Models\ClinetPaymet;
use App\Models\DailyRepotClient;
use App\Models\DoctorBalance;
use App\Models\GraphArchive;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Carbon;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
// !hushyor bolllll
// Route::get('/test-ewuygdsahdsa', function () {
//    Client::query()->delete();
//     GraphArchive::query()->delete();
// });

// Route::get('/test-1', function () {
//     $data =  DoctorBalance::whereNull('daily_repot_id')->get(['id', 'client_id']);
//     foreach ($data as $item) {
//         $find = DailyRepotClient::where('client_id', $item->client_id)->first();
//         if ($find) {
//             DoctorBalance::where('id', $item->id)->update(['daily_repot_id' => $find->daily_repot_id]);
//         }
//     }
//     $daily = DailyRepotClient::whereIn('client_id', $data->pluck('client_id'))->get();
//     return $data;
// });

// Route::get('/test-1', function () {
//     $client = Client::whereNotNull('parent_id')
//         ->whereDate('created_at', '2024-12-20')
//         ->where('user_id', 13)
//         ->get();
//     $ClinetPaymet = ClinetPaymet::whereDate('created_at', '2024-12-20')
//         // ->get()
//         ->where('user_id', 13);
//     // ->pluck('client_id')->unique()->count();
//     $DailyRepotClientData =     $client->map(function ($item) {
//         return [
//             'client_id' => $item->id,
//             'daily_repot_id' => 12,
//             'created_at' => Carbon::now()->subDay(), // Bir kun oldingi vaqt
//             'updated_at' => Carbon::now()->subDay(), // Bir kun oldingi vaqt
//         ];
//     });
//     // DailyRepotClient::insert($DailyRepotClientData->toArray());
//     return [
//         'client_count' => $ClinetPaymet->pluck('client_id')->unique()->count(),
//         'total_price' => $client->sum('pay_total_price'),
//         'balance' => $client->sum('pay_total_price'),
//         'pay_total_price' => $ClinetPaymet->sum('pay_total_price'),
//         'discount' => $ClinetPaymet->sum('discount'),
//         'cash_price' => $ClinetPaymet->sum('cash_price'),
//         'card_price' => $ClinetPaymet->sum('card_price'),
//         'transfer_price' => $ClinetPaymet->sum('transfer_price'),
//         'id_data' => $DailyRepotClientData->toArray()
//     ];
// });


// Route::group(['prefix' => 'branch'], function () {
//     Route::get('', [BranchController::class, 'index']);
//     Route::post('', [BranchController::class, 'store']);
//     Route::get('/{id}', [BranchController::class, 'show']);
//     Route::put('/{id}', [BranchController::class, 'update']);
//     Route::delete('/{id}', [BranchController::class, 'delete']);
// });



// Route::post('/webhook', [TelegramBotController::class, 'webhook']);
// Route::post('/webhook', [TelegramBotController::class, 'webhook']);
// Route::post('/webhook', [TelegramController::class, 'webhookHandler']);
// Route::get('/telegram/set-webhook', [TelegramBotController::class, 'setWebhook']);
