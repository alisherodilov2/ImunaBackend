<?php

namespace App\Http\Controllers\auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginRequest;
use App\Http\Requests\Auth\PasswordChangeRequest;
use App\Http\Requests\Auth\SupperAdminLoginRequest;
use App\Http\Resources\User\ProfileResource;
use App\Models\User;
use App\Services\Api\Contracts\AuthServiceInterface;
use App\Traits\ApiResponse;
use Illuminate\Http\Request;

class AuthController extends Controller
{
    use ApiResponse;
    public $modelClass = User::class;
    public function supperAdminlogin(SupperAdminLoginRequest $request, AuthServiceInterface $service)
    {
        $request->validated();
        return $this->success($service->login($request, User::USER_ROLE_SUPPER_ADMIN));
    }
    public function login(LoginRequest $request, AuthServiceInterface $service)
    {
        $request->validated();
        return $this->success($service->login($request));
    }

    public function logout(Request $request, AuthServiceInterface $service)
    {
        return $this->success($service->logout($request));
    }
    public function profile(Request $request, AuthServiceInterface $service)
    {
        return $this->success(($service->profile($request)));
    }
    // public function profileUpdate(Request $request, UserServiceInterface $service)
    // {
    //     return $this->success(new ProfileResource($service->edit(auth()->id(), $request)));
    // }

    public function passwordChange(PasswordChangeRequest $request, AuthServiceInterface $service)
    {
        $request->validated();
        return $this->success($service->passwordChange($request));
    }
}
